<?php include('server.php') //connect to server.php file.?>
<!DOCTYPE html>
<html>
<head>
  <title>Stadium Stacker!</title>
  <!-- stylesheet link -->
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 <!-- login form -->
  <form method="post" action="login.php" class="formBorder">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
	  <!-- link to signup page -->
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html>