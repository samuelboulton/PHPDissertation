<!-- Session start PHP -->
<?php 
  session_start(); 
    // if not logged in.
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  // if logout, destroy session.
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
    <!-- style sheet -->
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
    <!-- Fonts -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Nav -->
    <nav>
        <div id="logo">
            <h4><a href="index.php" id="logoLink">Stadium Stacker</a></h4>
        </div>

        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="#" style="cursor: pointer">My Stadiums</a></li>
            <!-- When clicked, logout=! to destroy session -->
            <li><a href="index.php?logout='1'">Logout</a></li>
        </ul>

        <div class="burger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
    </nav>

	<main>
        <section class="presentation">
            <div class="introduction">
                <div class="intro-text">
                    <h1>Welcome <strong><?php echo $_SESSION['username']; ?></strong>!</h1>
                    <p>
                            Welcome to <span style="    background: linear-gradient(to right, #0b310b, #274b2f);
                            -webkit-background-clip: text;
                            -webkit-text-fill-color: transparent; font-weight: bold;">STADIUM STACKER!</span> This website lets you browse 
                            for stadiums and add them to your collection!
                    </p>
                </div>
                <div class="cta">
                    <button class="cta-select"><a id="logoutBtn" href="index.php?logout='1'">Logout</a></button>
                    <button class="cta-add"><a id="selectBtn" href="#">Add Stadiums</a></button>
                </div>
            </div>
            <img class="pres_img" src="homepage_stad1.jpg" atl="stadium">
        </section>
    </main>
</body>
</html>